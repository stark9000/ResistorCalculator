/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resistorcalculator;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

/**
 *
 * @author Saliya
 */
public class ResistorUI extends javax.swing.JFrame implements WindowListener {

    private final Color brown = new Color(165, 42, 42);
    private final Color violet = new Color(238, 130, 238);
    private final Color gold = new Color(255, 215, 0);
    private final Color silver = new Color(192, 192, 192);
    private final Color[] colors3 = {Color.BLACK, brown, Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.BLUE, violet, Color.GRAY, Color.WHITE};
    private final List<JComboBox> JCB = new ArrayList<>();
    private String b1b2 = "";
    private double yy = 0;
    private int tens = 0;
    public static boolean aboutOpen = false;

    public ResistorUI() {

        initComponents();
        startup();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        band1 = new javax.swing.JComboBox<>();
        band2 = new javax.swing.JComboBox<>();
        band3 = new javax.swing.JComboBox<>();
        band4 = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("4 Band Resistor Calculator Ver : 1.0");

        band1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BLACK", "BROWN", "RED", "ORANGE", "YELLOW", "GREEN", "BLUE", "VIOLET", "GRAY", "WHITE" }));
        band1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 204), 2));
        band1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                band1ActionPerformed(evt);
            }
        });

        band2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BLACK", "BROWN", "RED", "ORANGE", "YELLOW", "GREEN", "BLUE", "VIOLET", "GRAY", "WHITE" }));
        band2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 204), 2));
        band2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                band2ActionPerformed(evt);
            }
        });

        band3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BLACK", "BROWN", "RED", "ORANGE", "YELLOW", "GREEN", "BLUE", "VIOLET", "GRAY", "WHITE" }));
        band3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 204), 2));
        band3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                band3ActionPerformed(evt);
            }
        });

        band4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BLACK", "BROWN", "RED", "ORANGE", "YELLOW", "GREEN", "BLUE", "VIOLET", "GRAY", "WHITE", "GOLD", "SILVER" }));
        band4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 204), 2));
        band4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                band4ActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 102, 255), 2));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 209, Short.MAX_VALUE)
        );

        jButton1.setText("refresh");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("reset");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setForeground(new java.awt.Color(0, 102, 255));
        jButton3.setText("About");
        jButton3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 102, 255), 3, true));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 255), 2));

        jTextField1.setEditable(false);
        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("0.0");
        jTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ohms", "k Ohms", "M Ohms" }));
        jComboBox1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jComboBox1.setEnabled(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("%   +/-");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jComboBox2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "20", "1", "2", "3", "-0:+100", "0.5", "0.25", "0.10", "0.05", "10", "5", "10" }));
        jComboBox2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jComboBox2.setEnabled(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBox1)
                            .addComponent(jComboBox2)
                            .addComponent(jTextField1))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jButton4.setText("Q refresh");
        jButton4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText(" Rcal : Vr : 1.1");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel2.setIconTextGap(0);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(band1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(band2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(band3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(band4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(band1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(band2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(band3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(band4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 6, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Graphics2D G = (Graphics2D) jPanel1.getGraphics();
        G.setColor(new Color(102, 153, 153));
        G.fillRoundRect(jPanel1.getWidth() / 2 - 90, jPanel1.getHeight() / 2 - 50, 145, 100, 15, 15);
        G.setColor(Color.BLACK);
        G.fillRect(jPanel1.getWidth() / 2 - 145, jPanel1.getHeight() / 2, 55, 5);
        G.fillRect(jPanel1.getWidth() / 2 + 55, jPanel1.getHeight() / 2, 55, 5);

        switch (band1.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 80, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band2.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 50, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band3.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 20, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band4.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(gold);
                break;
            case 6:
                G.setColor(silver);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 + 20, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void band1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_band1ActionPerformed
        Graphics2D G = (Graphics2D) jPanel1.getGraphics();

        switch (band1.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[0], 2));
                break;
            case 1:
                G.setColor(colors3[1]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[1], 2));
                break;
            case 2:
                G.setColor(colors3[2]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[2], 2));
                break;
            case 3:
                G.setColor(colors3[3]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[3], 2));
                break;
            case 4:
                G.setColor(colors3[4]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[4], 2));
                break;
            case 5:
                G.setColor(colors3[5]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[5], 2));
                break;
            case 6:
                G.setColor(colors3[6]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[6], 2));
                break;
            case 7:
                G.setColor(colors3[7]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[7], 2));
                break;
            case 8:
                G.setColor(colors3[8]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[8], 2));
                break;
            case 9:
                G.setColor(colors3[9]);
                band1.setBorder(BorderFactory.createLineBorder(colors3[9], 2));
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }

        G.fillRoundRect(jPanel1.getWidth() / 2 - 80, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        calcr();
    }//GEN-LAST:event_band1ActionPerformed

    private void band2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_band2ActionPerformed
        Graphics2D G = (Graphics2D) jPanel1.getGraphics();

        switch (band2.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[0], 2));
                break;
            case 1:
                G.setColor(colors3[1]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[1], 2));
                break;
            case 2:
                G.setColor(colors3[2]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[2], 2));
                break;
            case 3:
                G.setColor(colors3[3]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[3], 2));
                break;
            case 4:
                G.setColor(colors3[4]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[4], 2));
                break;
            case 5:
                G.setColor(colors3[5]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[5], 2));
                break;
            case 6:
                G.setColor(colors3[6]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[6], 2));
                break;
            case 7:
                G.setColor(colors3[7]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[7], 2));
                break;
            case 8:
                G.setColor(colors3[8]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[8], 2));
                break;
            case 9:
                G.setColor(colors3[9]);
                band2.setBorder(BorderFactory.createLineBorder(colors3[9], 2));
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }

        G.fillRoundRect(jPanel1.getWidth() / 2 - 50, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        calcr();
    }//GEN-LAST:event_band2ActionPerformed

    private void band3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_band3ActionPerformed
        Graphics2D G = (Graphics2D) jPanel1.getGraphics();

        switch (band3.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[0], 2));
                break;
            case 1:
                G.setColor(colors3[1]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[1], 2));
                break;
            case 2:
                G.setColor(colors3[2]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[2], 2));
                break;
            case 3:
                G.setColor(colors3[3]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[3], 2));
                break;
            case 4:
                G.setColor(colors3[4]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[4], 2));
                break;
            case 5:
                G.setColor(colors3[5]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[5], 2));
                break;
            case 6:
                G.setColor(colors3[6]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[6], 2));
                break;
            case 7:
                G.setColor(colors3[7]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[7], 2));
                break;
            case 8:
                G.setColor(colors3[8]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[8], 2));
                break;
            case 9:
                G.setColor(colors3[9]);
                band3.setBorder(BorderFactory.createLineBorder(colors3[9], 2));
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }

        G.fillRoundRect(jPanel1.getWidth() / 2 - 20, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        calcr();
    }//GEN-LAST:event_band3ActionPerformed

    private void band4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_band4ActionPerformed
        Graphics2D G = (Graphics2D) jPanel1.getGraphics();

        switch (band4.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[0], 2));
                break;
            case 1:
                G.setColor(colors3[1]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[1], 2));
                break;
            case 2:
                G.setColor(colors3[2]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[2], 2));
                break;
            case 3:
                G.setColor(colors3[3]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[3], 2));
                break;
            case 4:
                G.setColor(colors3[4]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[4], 2));
                break;
            case 5:
                G.setColor(colors3[5]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[5], 2));
                break;
            case 6:
                G.setColor(colors3[6]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[6], 2));
                break;
            case 7:
                G.setColor(colors3[7]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[7], 2));
                break;
            case 8:
                G.setColor(colors3[8]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[8], 2));
                break;
            case 9:
                G.setColor(colors3[9]);
                band4.setBorder(BorderFactory.createLineBorder(colors3[9], 2));
                break;
            case 10:
                G.setColor(gold);
                band4.setBorder(BorderFactory.createLineBorder(gold, 2));
                break;
            case 11:
                G.setColor(silver);
                band4.setBorder(BorderFactory.createLineBorder(silver, 2));
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }

        G.fillRoundRect(jPanel1.getWidth() / 2 + 20, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        calct();
    }//GEN-LAST:event_band4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        band1.setSelectedIndex(0);
        band2.setSelectedIndex(0);
        band3.setSelectedIndex(0);
        band4.setSelectedIndex(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (aboutOpen) {
            return;
        } else {
            new about().setVisible(true);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        super.repaint();
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ResistorUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ResistorUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ResistorUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ResistorUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new ResistorUI().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> band1;
    private javax.swing.JComboBox<String> band2;
    private javax.swing.JComboBox<String> band3;
    private javax.swing.JComboBox<String> band4;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

    private void startup() {
        Image image;
        try {
            image = ImageIO.read(getClass().getClassLoader().getResource("resistorcalculator/icon2.png"));
            super.setIconImage(image);
        } catch (IOException ex) {
        }
        addWindowListener(this);
        loadBoxes();
        this.setResizable(false);
        JCB.add(this.band1);
        JCB.add(this.band2);
        JCB.add(this.band3);
        for (int i = 0; i < 3; i++) {
            JCB.get(i).setRenderer(new DefaultListCellRenderer() {
                @Override
                public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                    Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                    if (c instanceof JLabel) {
                        JLabel l = (JLabel) c;
                        switch (list.getSelectedIndex()) {
                            case 0:
                                list.setSelectionBackground(colors3[0]);
                                break;
                            case 1:
                                list.setSelectionBackground(colors3[1]);
                                break;
                            case 2:
                                list.setSelectionBackground(colors3[2]);
                                break;
                            case 3:
                                list.setSelectionBackground(colors3[3]);
                                break;
                            case 4:
                                list.setSelectionBackground(colors3[4]);
                                break;
                            case 5:
                                list.setSelectionBackground(colors3[5]);
                                break;
                            case 6:
                                list.setSelectionBackground(colors3[6]);
                                break;
                            case 7:
                                list.setSelectionBackground(colors3[7]);
                                break;
                            case 8:
                                list.setSelectionBackground(colors3[8]);
                                break;
                            case 9:
                                list.setSelectionBackground(colors3[9]);
                                break;
                            default:
                                list.setSelectionBackground(Color.lightGray);
                                break;
                        }
                        return l;
                    }
                    return c;
                }

            });
        }

        band4.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (c instanceof JLabel) {
                    JLabel l = (JLabel) c;
                    switch (list.getSelectedIndex()) {
                        case 0:
                            list.setSelectionBackground(colors3[0]);
                            break;
                        case 1:
                            list.setSelectionBackground(colors3[1]);
                            break;
                        case 2:
                            list.setSelectionBackground(colors3[2]);
                            break;
                        case 3:
                            list.setSelectionBackground(colors3[3]);
                            break;
                        case 4:
                            list.setSelectionBackground(colors3[4]);
                            break;

                        case 5:
                            list.setSelectionBackground(colors3[5]);
                            break;
                        case 6:
                            list.setSelectionBackground(colors3[6]);
                            break;
                        case 7:
                            list.setSelectionBackground(colors3[7]);
                            break;
                        case 8:
                            list.setSelectionBackground(colors3[8]);
                            break;
                        case 9:
                            list.setSelectionBackground(colors3[9]);
                            break;
                        case 10:
                            list.setSelectionBackground(gold);
                            break;
                        case 11:
                            list.setSelectionBackground(silver);
                            break;
                        default:
                            list.setSelectionBackground(Color.lightGray);
                            break;

                    }
                    return l;
                }
                return c;
            }
        });

    }

    private void loadBoxes() {

        Graphics2D G = (Graphics2D) jPanel1.getGraphics();
        G.setColor(new Color(102, 153, 153));
        G.fillRoundRect(jPanel1.getWidth() / 2 - 90, jPanel1.getHeight() / 2 - 50, 145, 100, 15, 15);
        G.setColor(Color.BLACK);
        G.fillRect(jPanel1.getWidth() / 2 - 145, jPanel1.getHeight() / 2, 55, 5);
        G.fillRect(jPanel1.getWidth() / 2 + 55, jPanel1.getHeight() / 2, 55, 5);
        switch (band1.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 80, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band2.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 50, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band3.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 20, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band4.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;

            case 10:
                G.setColor(gold);
                break;
            case 11:
                G.setColor(silver);
                break;

            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 + 20, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);

    }

    @Override
    public void windowOpened(WindowEvent we) {

    }

    @Override
    public void windowClosing(WindowEvent we) {
        int dialogResult = JOptionPane.showConfirmDialog(null, "Would you like to quit now ?", "Quit", JOptionPane.YES_NO_OPTION);
        if (dialogResult == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    @Override
    public void windowClosed(WindowEvent we) {

    }

    @Override
    public void windowIconified(WindowEvent we) {

    }

    @Override
    public void windowDeiconified(WindowEvent we) {

    }

    @Override
    public void windowActivated(WindowEvent we) {

    }

    @Override
    public void windowDeactivated(WindowEvent we) {

    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        loadBoxes();
    }

    private void calcr() {
        b1b2 = String.valueOf(band1.getSelectedIndex()) + String.valueOf(band2.getSelectedIndex());
        yy = Integer.valueOf(b1b2) * (int) Math.pow(10, band3.getSelectedIndex());
        tens = (int) (float) (Math.log(1 * (int) Math.pow(10, band3.getSelectedIndex())) / Math.log(10));
        if (tens > 1) {
            if (tens >= 5) {
                jTextField1.setText(String.valueOf(yy / 1000000));
            } else {
                jTextField1.setText(String.valueOf(yy / 1000));
            }
        } else {
            jTextField1.setText(String.valueOf(yy));
        }

        if ((yy) >= 1e6) {
            jComboBox1.setSelectedIndex(2);
        } else if ((yy) >= 1e3) {
            jComboBox1.setSelectedIndex(1);
        } else {
            jComboBox1.setSelectedIndex(0);
        }
        super.repaint();
    }

    public void refresh() {
        Graphics2D G = (Graphics2D) jPanel1.getGraphics();
        G.setColor(new Color(102, 153, 153));
        G.fillRoundRect(jPanel1.getWidth() / 2 - 90, jPanel1.getHeight() / 2 - 50, 145, 100, 15, 15);
        G.setColor(Color.BLACK);
        G.fillRect(jPanel1.getWidth() / 2 - 145, jPanel1.getHeight() / 2, 55, 5);
        G.fillRect(jPanel1.getWidth() / 2 + 55, jPanel1.getHeight() / 2, 55, 5);

        switch (band1.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 80, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band2.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 50, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band3.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(colors3[5]);
                break;
            case 6:
                G.setColor(colors3[6]);
                break;
            case 7:
                G.setColor(colors3[7]);
                break;
            case 8:
                G.setColor(colors3[8]);
                break;
            case 9:
                G.setColor(colors3[9]);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 - 20, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
        switch (band4.getSelectedIndex()) {
            case 0:
                G.setColor(colors3[0]);
                break;
            case 1:
                G.setColor(colors3[1]);
                break;
            case 2:
                G.setColor(colors3[2]);
                break;
            case 3:
                G.setColor(colors3[3]);
                break;
            case 4:
                G.setColor(colors3[4]);
                break;
            case 5:
                G.setColor(gold);
                break;
            case 6:
                G.setColor(silver);
                break;
            default:
                G.setColor(Color.lightGray);
                break;
        }
        G.fillRoundRect(jPanel1.getWidth() / 2 + 20, jPanel1.getHeight() / 2 - 40, 20, 80, 10, 10);
    }

    private void calct() {
        switch (band4.getSelectedIndex()) {

            case 0:
                jComboBox2.setSelectedIndex(0);
                break;
            case 1:
                jComboBox2.setSelectedIndex(1);
                break;
            case 2:
                jComboBox2.setSelectedIndex(2);
                break;
            case 3:
                jComboBox2.setSelectedIndex(3);
                break;
            case 4:
                jComboBox2.setSelectedIndex(4);
                break;
            case 5:
                jComboBox2.setSelectedIndex(5);
                break;
            case 6:
                jComboBox2.setSelectedIndex(6);
                break;
            case 7:
                jComboBox2.setSelectedIndex(7);
                break;
            case 8:
                jComboBox2.setSelectedIndex(8);
                break;
            case 9:
                jComboBox2.setSelectedIndex(9);
                break;
            case 10:
                jComboBox2.setSelectedIndex(10);
                break;
            case 11:
                jComboBox2.setSelectedIndex(11);
                break;
            default:
                jComboBox2.setSelectedIndex(0);
                break;
        }
        super.repaint();
    }
}
